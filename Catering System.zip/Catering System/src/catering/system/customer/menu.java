/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package catering.system.customer;

import catering.system.UserSession;
import javax.swing.JFrame;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableModel;


/**
 *
 * @author Dell
 */
public class menu extends javax.swing.JFrame {
    int customerID = UserSession.getCustomerId();
     DefaultTableModel cartModel;      

// ---------------- BUTTON RENDERER (shows button cell) ----------------
class ButtonRenderer extends javax.swing.JButton implements javax.swing.table.TableCellRenderer {
    public ButtonRenderer() {
        setText("Order");
    }

    @Override
    public java.awt.Component getTableCellRendererComponent(
        javax.swing.JTable table, Object value, boolean isSelected,
        boolean hasFocus, int row, int column) {

        return this;
    }
}

// ---------------- BUTTON EDITOR (handles click) ----------------
// ---------------- BUTTON EDITOR (handles ORDER button click) ----------------
class ButtonEditor extends javax.swing.DefaultCellEditor {

    protected javax.swing.JButton btn;
    private boolean clicked;
    private int row;

    public ButtonEditor(javax.swing.JTextField txt) {
        super(txt);
        btn = new javax.swing.JButton("Order");
        btn.setOpaque(true);
        btn.addActionListener(e -> fireEditingStopped());
    }

    @Override
    public java.awt.Component getTableCellEditorComponent(
        javax.swing.JTable table, Object value, boolean isSelected,
        int row, int col) {

        this.row = row;
        clicked = true;
        return btn;
    }

    @Override
    public Object getCellEditorValue() {
        if (clicked) {

            // Get menu item details
            String itemName = jTable1.getValueAt(row, 0).toString();
            double price = Double.parseDouble(jTable1.getValueAt(row, 3).toString());

            boolean exists = false;

            // Check if item already exists in cart
            for (int i = 0; i < cartModel.getRowCount(); i++) {
                if (cartModel.getValueAt(i, 0).toString().equals(itemName)) {
                    int qty = Integer.parseInt(cartModel.getValueAt(i, 2).toString());
                    cartModel.setValueAt(qty + 1, i, 2);
                    exists = true;
                    break;
                }
            }

            // Add new cart row
            if (!exists) {
                cartModel.addRow(new Object[]{ itemName, price, 1 });
            }

            JOptionPane.showMessageDialog(null, itemName + " added to cart!");
        }

        clicked = false;
        return btn;
    }

    @Override
    public boolean stopCellEditing() {
        clicked = false;
        return super.stopCellEditing();
    }
    


}
// ---------------- MINUS BUTTON RENDERER ----------------
class MinusRenderer extends javax.swing.JButton implements javax.swing.table.TableCellRenderer {
    public MinusRenderer() {
        setText("remove");
    }

    @Override
    public java.awt.Component getTableCellRendererComponent(
        javax.swing.JTable table, Object value, boolean isSelected,
        boolean hasFocus, int row, int column) {

        return this;
    }
}

// ---------------- MINUS BUTTON EDITOR ----------------
class MinusEditor extends javax.swing.DefaultCellEditor {

    protected javax.swing.JButton btn;
    private boolean clicked;
    private int row;

    public MinusEditor(javax.swing.JTextField txt) {
        super(txt);
        btn = new javax.swing.JButton("-");
        btn.setOpaque(true);
        btn.addActionListener(e -> fireEditingStopped());
    }

    @Override
    public java.awt.Component getTableCellEditorComponent(
        javax.swing.JTable table, Object value, boolean isSelected,
        int row, int col) {

        this.row = row;
        clicked = true;
        return btn;
    }

    @Override
    public Object getCellEditorValue() {

    if (clicked) {

        // If cart is empty or row is invalid → do nothing
        if (row < 0 || row >= cartModel.getRowCount()) {
            clicked = false;
            return btn;
        }

        int qty = Integer.parseInt(cartModel.getValueAt(row, 2).toString());

        if (qty > 1) {
            cartModel.setValueAt(qty - 1, row, 2);
        } else {
            cartModel.removeRow(row);
        }
    }

    clicked = false;
    return btn;
    }
}


    /**
     * Creates new form dashboard
     */
    public menu() {
   
    initComponents();  // NetBeans model is applied here
    applyLargeFont();
    // NOW override the NetBeans model
    cartModel = new DefaultTableModel(
        new Object[]{"Item", "Price", "Qty", "Remove"}, 0
    );
    jTable3.setModel(cartModel);

    jTable3.setRowHeight(30);
    jTable3.setFont(new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 18));

    // ADD MINUS BUTTON
    jTable3.getColumnModel().getColumn(3).setCellRenderer(new MinusRenderer());
    jTable3.getColumnModel().getColumn(3).setCellEditor(new MinusEditor(new javax.swing.JTextField()));

    // menu table settings
    jTable1.setFont(new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 18));
    jTable1.setRowHeight(30);

    loadMenuData();

    // ADD ORDER BUTTON
    jTable1.getColumnModel().getColumn(5).setCellRenderer(new ButtonRenderer());
    jTable1.getColumnModel().getColumn(5).setCellEditor(new ButtonEditor(new javax.swing.JTextField()));

    setLocationRelativeTo(null);
    this.setExtendedState(JFrame.MAXIMIZED_BOTH);
}

    
    private void loadMenuData() {
    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
    model.setRowCount(0); // Clear table

    try {
        Connection con = DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/booking_system", "root", ""
        );

        String sql = "SELECT item_name, category, description, price, availability FROM menu_items";
        PreparedStatement pst = con.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();

        while (rs.next()) {
            model.addRow(new Object[]{
                rs.getString("item_name"),
                rs.getString("category"),
                rs.getString("description"),
                rs.getDouble("price"),
                rs.getString("availability"),
                "Order"   // for button later
            });
        }

        rs.close();
        pst.close();
        con.close();

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error loading menu: " + e.getMessage());
    }
}


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        dashboardbtn = new javax.swing.JButton();
        bookingsbtn = new javax.swing.JButton();
        paymentsbtn = new javax.swing.JButton();
        menubtn = new javax.swing.JButton();
        feedbackbtn = new javax.swing.JButton();
        profilebtn = new javax.swing.JButton();
        logoutbtn = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        PlaceOrder = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        dashboardbtn.setText("dashboard");
        dashboardbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dashboardbtnActionPerformed(evt);
            }
        });

        bookingsbtn.setText("Bookings");
        bookingsbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bookingsbtnActionPerformed(evt);
            }
        });

        paymentsbtn.setText("Payments");
        paymentsbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                paymentsbtnActionPerformed(evt);
            }
        });

        menubtn.setText("Menu");
        menubtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menubtnActionPerformed(evt);
            }
        });

        feedbackbtn.setText("Feedback");
        feedbackbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                feedbackbtnActionPerformed(evt);
            }
        });

        profilebtn.setText("Profile");
        profilebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                profilebtnActionPerformed(evt);
            }
        });

        logoutbtn.setText("Logout");
        logoutbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutbtnActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Item Name", "Category", "Description", "Price", "Availability", "Order"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Item Name", "Category", "Description", "Price", "Availability", "Order"
            }
        ));
        jScrollPane3.setViewportView(jTable3);

        PlaceOrder.setText("Place Order");
        PlaceOrder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PlaceOrderActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(profilebtn, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(feedbackbtn, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(paymentsbtn, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(bookingsbtn, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(dashboardbtn, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 169, Short.MAX_VALUE)
                    .addComponent(menubtn, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(logoutbtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 837, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 781, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(27, 27, 27))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(PlaceOrder, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(54, 54, 54))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addComponent(dashboardbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(menubtn, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(bookingsbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(paymentsbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(feedbackbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(profilebtn, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(logoutbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 590, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 590, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(26, 26, 26)
                        .addComponent(PlaceOrder, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(606, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    private void setUIFont(javax.swing.plaf.FontUIResource f){
    java.util.Enumeration keys = UIManager.getDefaults().keys();
    while(keys.hasMoreElements()){
        Object key = keys.nextElement();
        Object value = UIManager.get(key);
        if(value instanceof javax.swing.plaf.FontUIResource){
            UIManager.put(key, f);
        }
    }
}
    private void applyLargeFont() {

    java.awt.Font buttonFont = new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 24);
    java.awt.Font tableFont = new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 20);
    java.awt.Font headerFont = new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 22);

    // ----- SIDEBAR BUTTONS -----
    javax.swing.JButton[] buttons = {
        dashboardbtn, bookingsbtn, paymentsbtn,
        menubtn, feedbackbtn, profilebtn, logoutbtn
    };

    for (javax.swing.JButton b : buttons) {
        b.setFont(buttonFont);
        b.setFocusable(false);
    }

    // ----- PLACE ORDER BUTTON -----
    PlaceOrder.setFont(buttonFont);

    // ----- MENU TABLE -----
    jTable1.setFont(tableFont);
    jTable1.setRowHeight(32);
    jTable1.getTableHeader().setFont(headerFont);

    // ----- CART TABLE -----
    jTable3.setFont(tableFont);
    jTable3.setRowHeight(32);
    jTable3.getTableHeader().setFont(headerFont);

    // ----- BUTTON TEXT INSIDE TABLES -----
    // Order button
    if (jTable1.getColumnCount() > 5) {
        jTable1.getColumnModel().getColumn(5).setCellRenderer(new ButtonRenderer());
    }

    // Remove button (cart)
    if (jTable3.getColumnCount() > 3) {
        jTable3.getColumnModel().getColumn(3).setCellRenderer(new MinusRenderer());
    }
}


    private void dashboardbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dashboardbtnActionPerformed
        menu dashboard = new menu();
        dashboard.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_dashboardbtnActionPerformed

    private void bookingsbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bookingsbtnActionPerformed
        bookings bookings = new bookings();
        bookings.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_bookingsbtnActionPerformed

    private void paymentsbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_paymentsbtnActionPerformed
        payments payments = new payments();
        payments.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_paymentsbtnActionPerformed

    private void menubtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menubtnActionPerformed
        menu menu = new menu();
        menu.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_menubtnActionPerformed

    private void feedbackbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_feedbackbtnActionPerformed
        feedback feedback = new feedback();
        feedback.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_feedbackbtnActionPerformed

    private void profilebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_profilebtnActionPerformed
        profile profile = new profile();
        profile.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_profilebtnActionPerformed
    
    private void logoutbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutbtnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_logoutbtnActionPerformed
    
    private void PlaceOrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PlaceOrderActionPerformed
       System.out.println("DEBUG Customer ID = " + UserSession.getCustomerId());
System.out.println("DEBUG Booking ID = " + UserSession.getBookingId());
        // 1. Check if cart is empty
    if (cartModel.getRowCount() == 0) {
        JOptionPane.showMessageDialog(this, "Your cart is empty!", "Error", JOptionPane.WARNING_MESSAGE);
        return;
    }

    Connection con = null;

    try {
        // 2. Connect to DB
        con = DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/booking_system", "root", ""
        );

        // 3. Get booking & customer from session
        int bookingID = UserSession.getBookingId(); 
        int customerID = UserSession.getCustomerId();

        if (bookingID == 0) {
            JOptionPane.showMessageDialog(this, "No booking selected. Cannot place order.");
            return;
        }

        // 4. Compute total amount from cart
        double totalAmount = 0;
        for (int i = 0; i < cartModel.getRowCount(); i++) {
            double price = Double.parseDouble(cartModel.getValueAt(i, 1).toString());
            int qty = Integer.parseInt(cartModel.getValueAt(i, 2).toString());
            totalAmount += price * qty;
        }

        // 5. Insert into orders table
        // orders: order_id, booking_id, customer_id, order_date (default now), total_amount, status
        String orderSql = "INSERT INTO orders (booking_id, customer_id, total_amount, status) "
                        + "VALUES (?, ?, ?, 'Pending')";
        PreparedStatement pstOrder = con.prepareStatement(orderSql, java.sql.Statement.RETURN_GENERATED_KEYS);

        pstOrder.setInt(1, bookingID);
        pstOrder.setInt(2, customerID);
        pstOrder.setDouble(3, totalAmount);
        pstOrder.executeUpdate();

        // 6. Get generated order_id
        ResultSet rsOrder = pstOrder.getGeneratedKeys();
        int orderID = 0;
        if (rsOrder.next()) {
            orderID = rsOrder.getInt(1);
        } else {
            JOptionPane.showMessageDialog(this, "Failed to get generated order ID.");
            return;
        }

        // 7. Prepare helper statement to find menu_id by item_name
        String findMenuSql = "SELECT menu_id FROM menu_items WHERE item_name = ? LIMIT 1";
        PreparedStatement pstFindMenu = con.prepareStatement(findMenuSql);

        // 8. Prepare insert for order_items
        String itemSql = "INSERT INTO order_items (order_id, menu_id, quantity, price, subtotal) "
                       + "VALUES (?, ?, ?, ?, ?)";
        PreparedStatement pstItem = con.prepareStatement(itemSql);

        // 9. Loop through cart rows and insert each as order_items
        for (int i = 0; i < cartModel.getRowCount(); i++) {

            String itemName = cartModel.getValueAt(i, 0).toString();   // Item
            double price = Double.parseDouble(cartModel.getValueAt(i, 1).toString());  // Price
            int qty = Integer.parseInt(cartModel.getValueAt(i, 2).toString());         // Qty

            // 9a. Get menu_id from menu_items using item_name
            pstFindMenu.setString(1, itemName);
            ResultSet rsMenu = pstFindMenu.executeQuery();

            if (!rsMenu.next()) {
                // If no menu_id found, skip or show warning
                JOptionPane.showMessageDialog(this, 
                    "No menu_id found for item: " + itemName + ". Item will be skipped.");
                continue; // or return; if you want to cancel the whole order
            }

            int menuId = rsMenu.getInt("menu_id");
            double subtotal = price * qty;

            // 9b. Insert into order_items
            pstItem.setInt(1, orderID);
            pstItem.setInt(2, menuId);
            pstItem.setInt(3, qty);
            pstItem.setDouble(4, price);
            pstItem.setDouble(5, subtotal);

            pstItem.executeUpdate();
        }

        // 10. Success message and clear cart
        JOptionPane.showMessageDialog(this, 
            "Order placed successfully!\nOrder ID: " + orderID +
            "\nBooking ID: " + bookingID);

        cartModel.setRowCount(0);  // clear cart

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error placing order: " + e.getMessage());
    } finally {
        // 11. Close connection
        if (con != null) {
            try { con.close(); } catch (SQLException ex) { /* ignore */ }
        }
    }
    new payments().setVisible(true);
this.dispose();

    }//GEN-LAST:event_PlaceOrderActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new menu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton PlaceOrder;
    private javax.swing.JButton bookingsbtn;
    private javax.swing.JButton dashboardbtn;
    private javax.swing.JButton feedbackbtn;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable3;
    private javax.swing.JButton logoutbtn;
    private javax.swing.JButton menubtn;
    private javax.swing.JButton paymentsbtn;
    private javax.swing.JButton profilebtn;
    // End of variables declaration//GEN-END:variables
}
