package catering.system;

public class UserSession {

    private static int customerId = 0;   // Logged-in customer
    private static int bookingId = 0;    // Selected booking

    private static String fullname = "";
    private static String email = "";

    // ---------- CUSTOMER INFO ----------
    public static void setCustomerId(int id) {
        customerId = id;
    }

    public static int getCustomerId() {
        return customerId;
    }

    public static void setFullname(String name) {
        fullname = name;
    }

    public static String getFullname() {
        return fullname;
    }

    public static void setEmail(String mail) {
        email = mail;
    }

    public static String getEmail() {
        return email;
    }

    // ---------- BOOKING INFO ----------
    public static void setBookingId(int id) {
        bookingId = id;
    }

    public static int getBookingId() {
        return bookingId;
    }

    // ---------- SET ALL USER DATA ----------
    public static void setUser(int id, String name, String mail) {
        customerId = id;
        fullname = name;
        email = mail;
    }

    // ---------- CLEAR SESSION ----------
    public static void clear() {
        customerId = 0;
        bookingId = 0;
        fullname = "";
        email = "";
    }
}
